echo "Static site - no build required"
