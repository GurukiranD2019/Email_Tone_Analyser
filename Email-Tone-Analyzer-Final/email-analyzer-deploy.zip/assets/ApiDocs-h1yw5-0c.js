import{c as i,j as e,a as c}from"./index-C_MkKGYz.js";import{b as x}from"./vendor-DKTjyDxO.js";import{Z as j}from"./zap-Yy7ATLCQ.js";import{S as b,C as m}from"./shield-BTEdXX6z.js";import{C as N}from"./circle-check-big-CI2MwW8d.js";/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]],f=i("circle-alert",v);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]],A=i("copy",w);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]],P=i("external-link",T);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _=[["path",{d:"m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4",key:"g0fldk"}],["path",{d:"m21 2-9.6 9.6",key:"1j0ho8"}],["circle",{cx:"7.5",cy:"15.5",r:"5.5",key:"yqb3hr"}]],k=i("key",_);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]],E=i("play",I),O=()=>{const[o,d]=x.useState(null),[a,h]=x.useState("overview"),p=(s,t)=>{navigator.clipboard.writeText(s),d(t),setTimeout(()=>d(null),2e3)},n={javascript:`// JavaScript/Node.js Example
const response = await fetch('https://api.emailtoneanalyzer.com/v1/analyze', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
    email_content: "Dear Mr. Johnson, I hope this email finds you well...",
    options: {
      include_suggestions: true,
      confidence_threshold: 0.7
    }
  })
});

const analysis = await response.json();
console.log(analysis);`,python:`# Python Example
import requests

url = "https://api.emailtoneanalyzer.com/v1/analyze"
headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer YOUR_API_KEY"
}
data = {
    "email_content": "Dear Mr. Johnson, I hope this email finds you well...",
    "options": {
        "include_suggestions": True,
        "confidence_threshold": 0.7
    }
}

response = requests.post(url, json=data, headers=headers)
analysis = response.json()
print(analysis)`,curl:`# cURL Example
curl -X POST https://api.emailtoneanalyzer.com/v1/analyze \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -d '{
    "email_content": "Dear Mr. Johnson, I hope this email finds you well...",
    "options": {
      "include_suggestions": true,
      "confidence_threshold": 0.7
    }
  }'`,response:`{
  "success": true,
  "data": {
    "id": "analysis_12345",
    "timestamp": "2024-01-15T10:30:00Z",
    "overall_sentiment": "positive",
    "confidence": 0.85,
    "tones": {
      "positive": 75,
      "negative": 10,
      "neutral": 15,
      "formal": 80,
      "informal": 20,
      "confident": 70,
      "tentative": 30
    },
    "suggestions": [
      "The email has a professional and positive tone overall",
      "Consider adding specific agenda items for clarity"
    ],
    "keywords": ["professional", "hope", "well", "email"],
    "processing_time_ms": 1250
  }
}`},y=[{method:"POST",path:"/v1/analyze",description:"Analyze email content for tone and sentiment",status:"stable"},{method:"GET",path:"/v1/analysis/{id}",description:"Retrieve a specific analysis by ID",status:"stable"},{method:"GET",path:"/v1/history",description:"Get analysis history for your account",status:"stable"},{method:"POST",path:"/v1/batch",description:"Analyze multiple emails in batch",status:"beta"}],u=[{name:"email_content",type:"string",required:!0,description:"The email content to analyze (max 10,000 characters)"},{name:"options.include_suggestions",type:"boolean",required:!1,description:"Include improvement suggestions in response (default: true)"},{name:"options.confidence_threshold",type:"number",required:!1,description:"Minimum confidence score to include tones (0.0-1.0, default: 0.5)"},{name:"options.language",type:"string",required:!1,description:'Language code for analysis (currently only "en" supported)'}],g=[{id:"overview",label:"Overview",icon:c},{id:"authentication",label:"Authentication",icon:k},{id:"endpoints",label:"Endpoints",icon:m},{id:"examples",label:"Examples",icon:E}],l=({code:s,language:t,id:r})=>e.jsxs("div",{className:"relative bg-gray-900 rounded-lg overflow-hidden",children:[e.jsxs("div",{className:"flex items-center justify-between px-4 py-2 bg-gray-800",children:[e.jsx("span",{className:"text-sm text-gray-300 font-medium",children:t}),e.jsxs("button",{onClick:()=>p(s,r),className:"flex items-center space-x-1 text-gray-300 hover:text-white transition-colors",children:[o===r?e.jsx(N,{className:"h-4 w-4 text-green-400"}):e.jsx(A,{className:"h-4 w-4"}),e.jsx("span",{className:"text-xs",children:o===r?"Copied!":"Copy"})]})]}),e.jsx("pre",{className:"p-4 text-sm text-gray-100 overflow-x-auto",children:e.jsx("code",{children:s})})]});return e.jsx("div",{className:"min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-16",children:e.jsx("section",{className:"pt-16 pb-8 px-4 sm:px-6 lg:px-8",children:e.jsxs("div",{className:"max-w-6xl mx-auto",children:[e.jsxs("div",{className:"text-center mb-8",children:[e.jsx("h1",{className:"text-5xl font-bold text-gray-900 mb-4",children:"API Documentation"}),e.jsx("p",{className:"text-xl text-gray-600 max-w-3xl mx-auto",children:"Integrate Email Tone Analyzer into your applications with our powerful and easy-to-use REST API"})]}),e.jsxs("div",{className:"grid md:grid-cols-4 gap-6 mb-8",children:[e.jsxs("div",{className:"bg-white p-4 rounded-lg shadow-md text-center",children:[e.jsx(j,{className:"h-8 w-8 text-blue-600 mx-auto mb-2"}),e.jsx("div",{className:"text-2xl font-bold text-gray-900",children:"~1s"}),e.jsx("div",{className:"text-sm text-gray-600",children:"Response Time"})]}),e.jsxs("div",{className:"bg-white p-4 rounded-lg shadow-md text-center",children:[e.jsx(b,{className:"h-8 w-8 text-green-600 mx-auto mb-2"}),e.jsx("div",{className:"text-2xl font-bold text-gray-900",children:"99.9%"}),e.jsx("div",{className:"text-sm text-gray-600",children:"Uptime"})]}),e.jsxs("div",{className:"bg-white p-4 rounded-lg shadow-md text-center",children:[e.jsx(m,{className:"h-8 w-8 text-purple-600 mx-auto mb-2"}),e.jsx("div",{className:"text-2xl font-bold text-gray-900",children:"REST"}),e.jsx("div",{className:"text-sm text-gray-600",children:"API Type"})]}),e.jsxs("div",{className:"bg-white p-4 rounded-lg shadow-md text-center",children:[e.jsx(c,{className:"h-8 w-8 text-orange-600 mx-auto mb-2"}),e.jsx("div",{className:"text-2xl font-bold text-gray-900",children:"v1"}),e.jsx("div",{className:"text-sm text-gray-600",children:"API Version"})]})]}),e.jsxs("div",{className:"bg-white rounded-lg shadow-lg overflow-hidden",children:[e.jsx("div",{className:"border-b border-gray-200",children:e.jsx("nav",{className:"flex space-x-8 px-6",children:g.map(s=>e.jsxs("button",{onClick:()=>h(s.id),className:`flex items-center space-x-2 py-4 border-b-2 font-medium text-sm transition-colors ${a===s.id?"border-blue-600 text-blue-600":"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"}`,children:[e.jsx(s.icon,{className:"h-4 w-4"}),e.jsx("span",{children:s.label})]},s.id))})}),e.jsxs("div",{className:"p-6",children:[a==="overview"&&e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-2xl font-bold text-gray-900 mb-4",children:"Getting Started"}),e.jsx("p",{className:"text-gray-600 mb-4",children:"The Email Tone Analyzer API allows you to integrate advanced email sentiment and tone analysis into your applications. Our API is RESTful, uses JSON for data exchange, and provides real-time analysis with high accuracy."})]}),e.jsxs("div",{className:"grid md:grid-cols-2 gap-6",children:[e.jsxs("div",{className:"bg-blue-50 p-6 rounded-lg",children:[e.jsx("h3",{className:"text-lg font-semibold text-blue-900 mb-3",children:"Base URL"}),e.jsx("code",{className:"bg-white px-3 py-2 rounded text-sm text-blue-800 block",children:"https://api.emailtoneanalyzer.com"})]}),e.jsxs("div",{className:"bg-green-50 p-6 rounded-lg",children:[e.jsx("h3",{className:"text-lg font-semibold text-green-900 mb-3",children:"Rate Limits"}),e.jsxs("ul",{className:"text-green-800 space-y-1 text-sm",children:[e.jsx("li",{children:"• Free: 100 requests/day"}),e.jsx("li",{children:"• Pro: 10,000 requests/day"}),e.jsx("li",{children:"• Enterprise: Unlimited"})]})]})]}),e.jsx("div",{className:"bg-yellow-50 border border-yellow-200 rounded-lg p-4",children:e.jsxs("div",{className:"flex items-center",children:[e.jsx(f,{className:"h-5 w-5 text-yellow-600 mr-2"}),e.jsxs("p",{className:"text-yellow-800",children:[e.jsx("strong",{children:"Note:"})," This is a demo API documentation. The actual API is not yet available. This documentation shows what the API would look like when implemented."]})]})})]}),a==="authentication"&&e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-2xl font-bold text-gray-900 mb-4",children:"Authentication"}),e.jsx("p",{className:"text-gray-600 mb-4",children:"The API uses Bearer token authentication. Include your API key in the Authorization header for all requests."})]}),e.jsx(l,{code:"Authorization: Bearer YOUR_API_KEY",language:"HTTP Header",id:"auth-header"}),e.jsxs("div",{className:"bg-blue-50 p-6 rounded-lg",children:[e.jsx("h3",{className:"text-lg font-semibold text-blue-900 mb-3",children:"Getting Your API Key"}),e.jsxs("ol",{className:"text-blue-800 space-y-2",children:[e.jsx("li",{children:"1. Sign up for an account at our developer portal"}),e.jsx("li",{children:"2. Navigate to the API Keys section"}),e.jsx("li",{children:"3. Generate a new API key"}),e.jsx("li",{children:"4. Copy and store your key securely"})]}),e.jsxs("button",{className:"mt-4 inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors",children:[e.jsx(P,{className:"h-4 w-4 mr-2"}),"Get API Key"]})]})]}),a==="endpoints"&&e.jsxs("div",{className:"space-y-6",children:[e.jsx("div",{children:e.jsx("h2",{className:"text-2xl font-bold text-gray-900 mb-4",children:"API Endpoints"})}),e.jsx("div",{className:"space-y-4",children:y.map((s,t)=>e.jsxs("div",{className:"border border-gray-200 rounded-lg p-4",children:[e.jsxs("div",{className:"flex items-center justify-between mb-2",children:[e.jsxs("div",{className:"flex items-center space-x-3",children:[e.jsx("span",{className:`px-2 py-1 text-xs font-medium rounded ${s.method==="GET"?"bg-green-100 text-green-800":s.method==="POST"?"bg-blue-100 text-blue-800":"bg-purple-100 text-purple-800"}`,children:s.method}),e.jsx("code",{className:"text-sm font-mono text-gray-800",children:s.path})]}),e.jsx("span",{className:`px-2 py-1 text-xs font-medium rounded ${s.status==="stable"?"bg-green-100 text-green-800":"bg-yellow-100 text-yellow-800"}`,children:s.status})]}),e.jsx("p",{className:"text-gray-600",children:s.description})]},t))}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-xl font-semibold text-gray-900 mb-4",children:"Request Parameters"}),e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"w-full border border-gray-200 rounded-lg",children:[e.jsx("thead",{className:"bg-gray-50",children:e.jsxs("tr",{children:[e.jsx("th",{className:"px-4 py-3 text-left text-sm font-medium text-gray-900",children:"Parameter"}),e.jsx("th",{className:"px-4 py-3 text-left text-sm font-medium text-gray-900",children:"Type"}),e.jsx("th",{className:"px-4 py-3 text-left text-sm font-medium text-gray-900",children:"Required"}),e.jsx("th",{className:"px-4 py-3 text-left text-sm font-medium text-gray-900",children:"Description"})]})}),e.jsx("tbody",{className:"divide-y divide-gray-200",children:u.map((s,t)=>e.jsxs("tr",{children:[e.jsx("td",{className:"px-4 py-3 text-sm font-mono text-gray-800",children:s.name}),e.jsx("td",{className:"px-4 py-3 text-sm text-gray-600",children:s.type}),e.jsx("td",{className:"px-4 py-3 text-sm",children:e.jsx("span",{className:`px-2 py-1 text-xs font-medium rounded ${s.required?"bg-red-100 text-red-800":"bg-gray-100 text-gray-800"}`,children:s.required?"Required":"Optional"})}),e.jsx("td",{className:"px-4 py-3 text-sm text-gray-600",children:s.description})]},t))})]})})]})]}),a==="examples"&&e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-2xl font-bold text-gray-900 mb-4",children:"Code Examples"}),e.jsx("p",{className:"text-gray-600 mb-6",children:"Here are examples of how to use the API in different programming languages."})]}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold text-gray-900 mb-3",children:"JavaScript/Node.js"}),e.jsx(l,{code:n.javascript,language:"JavaScript",id:"js-example"})]}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold text-gray-900 mb-3",children:"Python"}),e.jsx(l,{code:n.python,language:"Python",id:"python-example"})]}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold text-gray-900 mb-3",children:"cURL"}),e.jsx(l,{code:n.curl,language:"bash",id:"curl-example"})]}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold text-gray-900 mb-3",children:"Response Example"}),e.jsx(l,{code:n.response,language:"JSON",id:"response-example"})]})]})]})]})]})})})};export{O as default};
