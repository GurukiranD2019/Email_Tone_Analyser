import{c as A,j as e,B as C,S as T,L as P}from"./index-C_MkKGYz.js";import{b as v,c as z}from"./vendor-DKTjyDxO.js";import{F as M}from"./file-text-mfs8_PCo.js";import{T as D}from"./target-CBj5S8gx.js";import{Z as E}from"./zap-Yy7ATLCQ.js";import{A as L}from"./arrow-right-XsJ42o0C.js";/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]],F=A("upload",R),r=[{id:"1",title:"Professional Business Inquiry",category:"business",content:`Dear Mr. Johnson,

I hope this email finds you well. I am writing to inquire about the possibility of scheduling a meeting to discuss our upcoming project collaboration.

Our team has been impressed with your company's recent work in the sustainable technology sector, and we believe there could be significant synergies between our organizations.

Would you be available for a call next week? I am flexible with timing and can accommodate your schedule.

Looking forward to your response.

Best regards,
Sarah Mitchell
Project Manager
GreenTech Solutions`},{id:"2",title:"Customer Complaint",category:"complaint",content:`To Whom It May Concern,

I am extremely disappointed with the service I received yesterday. The delivery was not only 3 hours late, but the package was also damaged when it arrived.

This is completely unacceptable, especially considering the premium price I paid for expedited shipping. I have been a loyal customer for over 5 years, and this experience has left me questioning whether I should continue doing business with your company.

I demand a full refund and an explanation for this poor service. If this matter is not resolved immediately, I will be forced to escalate this complaint and share my negative experience on social media.

I expect a response within 24 hours.

Frustrated Customer,
Robert Chen`},{id:"3",title:"Thank You Note",category:"appreciation",content:`Hi Jennifer,

I just wanted to take a moment to express my heartfelt gratitude for all your help during the conference last week. Your presentation was absolutely fantastic, and the insights you shared were incredibly valuable.

Thanks to your guidance, I was able to connect with several potential clients and learn about innovative approaches I hadn't considered before. You truly went above and beyond to make the event successful.

I'm excited about the possibility of collaborating on future projects and would love to grab coffee sometime to discuss ideas further.

With sincere appreciation,
Amanda Rodriguez
Marketing Director`},{id:"4",title:"Technical Support Request",category:"inquiry",content:`Hello Support Team,

I'm experiencing some technical difficulties with your software and could use some assistance. When I try to export data from the analytics dashboard, the system gives me an error message saying "Export failed - please try again later."

I've tried refreshing the page and logging out and back in, but the problem persists. This is affecting my ability to prepare reports for tomorrow's board meeting.

Could someone please help me resolve this issue as soon as possible? I'm using Chrome browser version 115.0.5790.110 on Windows 11.

My account details:
- Username: j.wilson@techcorp.com
- Plan: Professional
- Last successful export: July 30th

Thank you for your assistance.

Best,
James Wilson
Data Analyst
TechCorp Industries`},{id:"5",title:"Friendly Team Update",category:"casual",content:`Hey team! 👋

Hope everyone's having an awesome week! Just wanted to give you all a quick update on the marketing campaign we launched on Monday.

The numbers are looking pretty amazing so far - we're already at 150% of our projected engagement rate! 🎉 I think the new creative direction is really resonating with our audience.

Also, don't forget about our team lunch this Friday at that new pizza place downtown. Can't wait to celebrate our wins together!

Let me know if you have any questions. Keep being awesome! 

Cheers,
Alex
Marketing Team Lead`},{id:"6",title:"Urgent Project Deadline",category:"urgent",content:`Subject: URGENT - Project Deadline Moved Up

Hi everyone,

I just received word from the client that they need to move up our project deadline by two weeks. I know this is short notice, but we need to adapt quickly.

The new deadline is now August 15th instead of August 30th. This means we need to accelerate our timeline significantly.

I need everyone to:
1. Review your current tasks and identify what can be fast-tracked
2. Let me know if you need additional resources
3. Attend an emergency team meeting tomorrow at 9 AM

I understand this puts pressure on everyone, but I'm confident we can deliver quality work on time if we work together.

Please respond by EOD today with your availability and concerns.

Thanks,
David Park
Project Manager`},{id:"7",title:"Gentle Follow-up",category:"follow-up",content:`Hi Maria,

I hope you're doing well! I wanted to follow up on our conversation from last week about the potential partnership opportunity.

I know you mentioned you'd need some time to discuss this with your team, and I completely understand that these decisions take time. I just wanted to check in and see if you had any initial thoughts or questions I could help address.

No pressure at all - I'm happy to wait until you're ready. I just wanted to keep the lines of communication open.

If it would be helpful, I'd be glad to provide additional information about our services or set up a brief call with our technical team to answer any specific questions.

Looking forward to hearing from you when the timing is right.

Best wishes,
Lisa Chen
Business Development Manager`},{id:"8",title:"Enthusiastic Announcement",category:"announcement",content:`🚀 EXCITING NEWS ALERT! 🚀

Dear valued customers and partners,

We are absolutely THRILLED to announce the launch of our revolutionary new product line! After months of hard work and innovation, we're finally ready to share something truly special with you.

Introducing SmartFlow Pro - the game-changing solution that will transform how you manage your workflow! Here's what makes it incredible:

✨ 300% faster processing speeds
✨ AI-powered automation features
✨ Seamless integration with existing tools
✨ 24/7 customer support

Early bird pricing is available for the next 48 hours only! Don't miss out on this amazing opportunity to be among the first to experience the future of productivity.

Visit our website or call us immediately to secure your spot!

We can't wait for you to experience the magic!

With boundless excitement,
The Innovation Team
FutureTech Solutions`}],H={1:{id:"1",emailContent:r[0].content,timestamp:new Date,overallSentiment:"positive",confidence:.85,tones:{positive:75,negative:5,neutral:20,angry:2,enthusiastic:65,formal:85,informal:15,analytical:70,confident:80,tentative:20},suggestions:["The email has a professional and positive tone overall","Consider adding specific agenda items for the proposed meeting","The enthusiasm level is appropriate for business communication"],keywords:["professional","collaboration","synergies","impressed","flexible"]},2:{id:"2",emailContent:r[1].content,timestamp:new Date,overallSentiment:"negative",confidence:.95,tones:{positive:5,negative:90,neutral:5,angry:85,enthusiastic:10,formal:60,informal:40,analytical:30,confident:70,tentative:10},suggestions:["The tone is very negative and aggressive - consider softening the language","Focus on solution-seeking rather than blame","Remove ultimatums and threats for better resolution","Add more specific details about desired outcomes"],keywords:["disappointed","unacceptable","frustrated","demand","complaint"]},3:{id:"3",emailContent:r[2].content,timestamp:new Date,overallSentiment:"positive",confidence:.92,tones:{positive:95,negative:2,neutral:3,angry:1,enthusiastic:88,formal:40,informal:60,analytical:25,confident:85,tentative:15},suggestions:["Excellent use of gratitude and appreciation","The warm and genuine tone builds strong relationships","Consider being more specific about future collaboration ideas"],keywords:["gratitude","fantastic","valuable","appreciation","excited"]},4:{id:"4",emailContent:r[3].content,timestamp:new Date,overallSentiment:"neutral",confidence:.78,tones:{positive:20,negative:25,neutral:55,angry:15,enthusiastic:10,formal:75,informal:25,analytical:80,confident:60,tentative:40},suggestions:["Good technical detail and clear problem description","Professional tone appropriate for support requests","Consider adding urgency level for better prioritization"],keywords:["technical","assistance","error","support","resolution"]},5:{id:"5",emailContent:r[4].content,timestamp:new Date,overallSentiment:"positive",confidence:.91,tones:{positive:90,negative:3,neutral:7,angry:2,enthusiastic:95,formal:20,informal:80,analytical:40,confident:88,tentative:12},suggestions:["Great use of emojis and casual tone for team communication","Enthusiasm is contagious and motivating","Perfect balance of celebration and information sharing"],keywords:["awesome","amazing","celebrate","team","wins"]},6:{id:"6",emailContent:r[5].content,timestamp:new Date,overallSentiment:"neutral",confidence:.82,tones:{positive:30,negative:40,neutral:30,angry:20,enthusiastic:25,formal:70,informal:30,analytical:85,confident:75,tentative:25},suggestions:["Good balance of urgency and understanding","Clear action items help team focus","Consider acknowledging the inconvenience more explicitly","Add contingency plans for risk mitigation"],keywords:["urgent","deadline","accelerate","pressure","confident"]},7:{id:"7",emailContent:r[6].content,timestamp:new Date,overallSentiment:"positive",confidence:.87,tones:{positive:80,negative:5,neutral:15,angry:2,enthusiastic:45,formal:65,informal:35,analytical:35,confident:70,tentative:30},suggestions:["Excellent use of patience and understanding","Non-pressuring approach shows professionalism","Consider offering a specific timeline for next follow-up"],keywords:["follow-up","patience","understanding","communication","timing"]},8:{id:"8",emailContent:r[7].content,timestamp:new Date,overallSentiment:"positive",confidence:.96,tones:{positive:98,negative:1,neutral:1,angry:0,enthusiastic:99,formal:45,informal:55,analytical:20,confident:95,tentative:5},suggestions:["Extremely high enthusiasm may overwhelm some readers","Consider toning down superlatives for broader appeal","Good use of bullet points for feature highlights","Strong call-to-action with urgency"],keywords:["thrilled","revolutionary","incredible","amazing","excitement"]}};class y{static instance;analysisHistory=[];constructor(){}static getInstance(){return y.instance||(y.instance=new y),y.instance}async analyzeEmail(n){try{await new Promise(a=>setTimeout(a,2e3));const s=Object.values(H).find(a=>a.emailContent===n);if(s)return this.analysisHistory.push(s),{success:!0,data:s};const o=this.generateAnalysis(n);return this.analysisHistory.push(o),{success:!0,data:o}}catch{return{success:!1,error:"Failed to analyze email. Please try again."}}}generateAnalysis(n){const s=Math.random().toString(36).substr(2,9),o=["thank","great","excellent","appreciate","wonderful","amazing","fantastic","love","pleased","happy"],a=["terrible","awful","disappointed","angry","frustrated","unacceptable","complaint","problem","issue","wrong"],l=["dear","sincerely","regards","respectfully","professional","kindly","please","thank you"],x=["furious","outraged","disgusted","livid","infuriated","demand","immediately","unacceptable"],d=n.toLowerCase().split(/\s+/),b=d.filter(h=>o.some(g=>h.includes(g))).length,w=d.filter(h=>a.some(g=>h.includes(g))).length,j=d.filter(h=>l.some(g=>h.includes(g))).length,N=d.filter(h=>x.some(g=>h.includes(g))).length,p=d.length,f=Math.min(90,j/p*500);let u,t=Math.max(10,Math.min(90,b/p*400)),i=Math.max(5,Math.min(85,w/p*400)),m=Math.max(0,Math.min(80,N/p*600));b>w?(u="positive",t+=20):w>b?(u="negative",i+=20):u="neutral";const k=Math.max(10,100-t-i),I=this.generateSuggestions(u,f,m),S=this.extractKeywords(n);return{id:s,emailContent:n,timestamp:new Date,overallSentiment:u,confidence:Math.random()*.3+.7,tones:{positive:Math.round(t),negative:Math.round(i),neutral:Math.round(k),angry:Math.round(m),enthusiastic:Math.round(t*.8),formal:Math.round(f),informal:Math.round(100-f),analytical:Math.round(Math.random()*40+40),confident:Math.round(Math.random()*30+50),tentative:Math.round(Math.random()*30+20)},suggestions:I,keywords:S}}generateSuggestions(n,s,o){const a=[];return n==="negative"&&a.push("Consider using more positive language to improve the tone"),o>60&&(a.push("The email contains strong negative emotions. Consider revising for a more professional tone"),a.push("Try to focus on solutions rather than problems")),s<40&&a.push("Consider using more formal language for professional communication"),s>80&&a.push("The tone is very formal. Consider adding some warmth if appropriate"),n==="positive"&&a.push("Great job! The email has a positive and engaging tone"),a}extractKeywords(n){const o=n.toLowerCase().replace(/[^\w\s]/g,"").split(/\s+/).filter(a=>a.length>3).filter(a=>!["this","that","with","have","will","been","from","they","were","said","each","which","their","time","would","there","about","could","other","make","what","know","just","first","into","over","think","also","your","work","life","only","can","still","should","after","being","now","made","before","here","through","when","where","much","good","well","some","very","more","most","many"].includes(a)).reduce((a,l)=>(a[l]=(a[l]||0)+1,a),{});return Object.entries(o).sort(([,a],[,l])=>l-a).slice(0,5).map(([a])=>a)}getAnalysisHistory(){return[...this.analysisHistory]}getAnalysisById(n){return this.analysisHistory.find(s=>s.id===n)}}const J=()=>{const[c,n]=v.useState(""),[s,o]=v.useState(!1),[a,l]=v.useState(""),[x,d]=v.useState(!1),b=z(),w=y.getInstance();v.useEffect(()=>{d(!0)},[]);const j=async()=>{if(!c.trim()){alert("Please enter email content to analyze");return}o(!0);try{const t=await w.analyzeEmail(c);t.success&&t.data?b("/result",{state:{analysis:t.data}}):alert(t.error||"Analysis failed. Please try again.")}catch{alert("An error occurred during analysis. Please try again.")}finally{o(!1)}},N=t=>{const i=r.find(m=>m.id===t);i&&(n(i.content),l(t))},p=t=>{const i=t.target.files?.[0];if(i&&i.type==="text/plain"){const m=new FileReader;m.onload=k=>{const I=k.target?.result;n(I)},m.readAsText(i)}else alert("Please upload a .txt file")},f=t=>{switch(t){case"business":return"from-blue-600 to-blue-500";case"complaint":return"from-red-600 to-red-500";case"appreciation":return"from-green-600 to-green-500";case"inquiry":return"from-yellow-600 to-yellow-500";case"casual":return"from-purple-600 to-purple-500";case"urgent":return"from-orange-600 to-orange-500";case"follow-up":return"from-indigo-600 to-indigo-500";case"announcement":return"from-pink-600 to-pink-500";default:return"from-gray-600 to-gray-500"}},u=t=>{switch(t){case"business":return"bg-blue-100 text-blue-800";case"complaint":return"bg-red-100 text-red-800";case"appreciation":return"bg-green-100 text-green-800";case"inquiry":return"bg-yellow-100 text-yellow-800";case"casual":return"bg-purple-100 text-purple-800";case"urgent":return"bg-orange-100 text-orange-800";case"follow-up":return"bg-indigo-100 text-indigo-800";case"announcement":return"bg-pink-100 text-pink-800";default:return"bg-gray-100 text-gray-800"}};return e.jsxs("div",{className:"min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-50 pt-16",children:[e.jsxs("div",{className:"absolute inset-0 overflow-hidden",children:[e.jsx("div",{className:"absolute top-20 right-10 w-60 h-60 bg-gradient-to-br from-blue-100/50 to-indigo-100/30 rounded-full blur-3xl animate-pulse-slow"}),e.jsx("div",{className:"absolute bottom-20 left-10 w-80 h-80 bg-gradient-to-br from-indigo-100/40 to-blue-100/20 rounded-full blur-3xl animate-pulse-slow",style:{animationDelay:"2s"}})]}),e.jsxs("div",{className:"max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative z-10",children:[e.jsxs("div",{className:`text-center mb-12 transition-all duration-1000 ${x?"opacity-100 translate-y-0":"opacity-0 translate-y-10"}`,children:[e.jsxs("div",{className:"inline-flex items-center space-x-2 bg-white/80 backdrop-blur-sm border border-gray-200/50 rounded-full px-4 py-2 mb-6 shadow-lg",children:[e.jsx(C,{className:"h-4 w-4 text-blue-600"}),e.jsx("span",{className:"text-sm font-medium text-gray-700",children:"AI-Powered Analysis"})]}),e.jsxs("h1",{className:"text-5xl md:text-6xl font-bold text-gray-900 mb-6",children:["Analyze Email"," ",e.jsx("span",{className:"bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent",children:"Tone"})]}),e.jsx("p",{className:"text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed",children:"Paste your email content below or choose from our sample emails to get started with intelligent tone analysis"})]}),e.jsxs("div",{className:`mb-12 transition-all duration-1000 delay-300 ${x?"opacity-100 translate-y-0":"opacity-0 translate-y-10"}`,children:[e.jsxs("h2",{className:"text-2xl font-bold text-gray-900 mb-6 flex items-center",children:[e.jsx(T,{className:"h-6 w-6 mr-2 text-blue-500"}),"Try with Sample Emails"]}),e.jsx("div",{className:"grid md:grid-cols-2 lg:grid-cols-3 gap-6",children:r.map((t,i)=>e.jsxs("button",{onClick:()=>N(t.id),className:`group relative p-6 text-left border-2 rounded-xl transition-all duration-300 hover-lift card-hover animate-fadeInUp ${a===t.id?"border-blue-500 bg-blue-50/50 shadow-lg":"border-gray-200 bg-white/80 backdrop-blur-sm hover:border-blue-300"}`,style:{animationDelay:`${i*.1}s`},children:[e.jsx("div",{className:`absolute inset-0 bg-gradient-to-br ${f(t.category)} opacity-0 group-hover:opacity-5 rounded-xl transition-opacity duration-300`}),e.jsxs("div",{className:"relative",children:[e.jsxs("div",{className:"flex items-center justify-between mb-3",children:[e.jsx("span",{className:`px-3 py-1 text-xs font-medium rounded-full ${u(t.category)}`,children:t.category}),e.jsx("div",{className:`w-3 h-3 rounded-full bg-gradient-to-br ${f(t.category)}`})]}),e.jsx("h3",{className:"font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-all duration-300",children:t.title}),e.jsxs("p",{className:"text-sm text-gray-600 line-clamp-2",children:[t.content.substring(0,120),"..."]}),e.jsxs("div",{className:"mt-3 flex items-center text-xs text-gray-500",children:[e.jsx(M,{className:"h-3 w-3 mr-1"}),t.content.split(" ").length," words"]})]})]},t.id))})]}),e.jsxs("div",{className:`bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-gray-200/50 p-8 glass transition-all duration-1000 delay-500 ${x?"opacity-100 translate-y-0":"opacity-0 translate-y-10"}`,children:[e.jsxs("div",{className:"mb-8",children:[e.jsxs("div",{className:"flex items-center justify-between mb-6",children:[e.jsxs("label",{htmlFor:"email-content",className:"text-2xl font-bold text-gray-900 flex items-center",children:[e.jsx(D,{className:"h-6 w-6 mr-2 text-blue-600"}),"Email Content"]}),e.jsx("div",{className:"flex items-center space-x-3",children:e.jsxs("label",{className:"group flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg cursor-pointer hover:bg-gray-200 transition-all duration-300 hover-lift",children:[e.jsx(F,{className:"h-4 w-4 mr-2 group-hover:scale-110 transition-transform"}),"Upload .txt file",e.jsx("input",{type:"file",accept:".txt",onChange:p,className:"hidden"})]})})]}),e.jsxs("div",{className:"relative",children:[e.jsx("textarea",{id:"email-content",value:c,onChange:t=>n(t.target.value),placeholder:"Paste your email content here...",className:"w-full h-80 p-6 border-2 border-gray-200 rounded-xl focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 resize-none form-input custom-scrollbar transition-all duration-300"}),c&&e.jsxs("div",{className:"absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1 border border-gray-200",children:[e.jsx(E,{className:"h-4 w-4 text-green-500 inline mr-1"}),e.jsx("span",{className:"text-sm font-medium text-gray-700",children:"Ready to analyze"})]})]}),e.jsxs("div",{className:"flex justify-between items-center mt-4 text-sm text-gray-500",children:[e.jsxs("span",{className:"flex items-center",children:[e.jsx(M,{className:"h-4 w-4 mr-1"}),c.length," characters"]}),e.jsxs("span",{children:[c.split(/\s+/).filter(t=>t.length>0).length," ","words"]})]})]}),e.jsxs("div",{className:"text-center mb-8",children:[e.jsx("button",{onClick:j,disabled:!c.trim()||s,className:"group inline-flex items-center px-10 py-5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-lg rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-xl hover:shadow-2xl disabled:opacity-50 disabled:cursor-not-allowed hover-lift",children:s?e.jsxs(e.Fragment,{children:[e.jsx(P,{className:"h-6 w-6 mr-3 animate-spin"}),"Analyzing Magic in Progress..."]}):e.jsxs(e.Fragment,{children:[e.jsx(T,{className:"h-6 w-6 mr-3 group-hover:scale-110 transition-transform"}),"Analyze Tone",e.jsx(L,{className:"ml-3 h-6 w-6 group-hover:translate-x-1 transition-transform"})]})}),s&&e.jsx("div",{className:"mt-4 text-center",children:e.jsxs("div",{className:"inline-flex items-center space-x-2 text-gray-600",children:[e.jsx("div",{className:"w-2 h-2 bg-blue-600 rounded-full animate-bounce"}),e.jsx("div",{className:"w-2 h-2 bg-purple-600 rounded-full animate-bounce",style:{animationDelay:"0.1s"}}),e.jsx("div",{className:"w-2 h-2 bg-pink-600 rounded-full animate-bounce",style:{animationDelay:"0.2s"}}),e.jsx("span",{className:"ml-3 text-sm",children:"Processing your email with AI..."})]})})]}),e.jsxs("div",{className:"p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl border border-blue-200/50",children:[e.jsxs("h3",{className:"font-bold text-blue-900 mb-3 flex items-center",children:[e.jsx(C,{className:"h-5 w-5 mr-2"}),"Pro Tips for Better Analysis"]}),e.jsxs("div",{className:"grid md:grid-cols-2 gap-4 text-sm text-blue-800",children:[e.jsxs("div",{className:"flex items-start space-x-2",children:[e.jsx("div",{className:"w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"}),e.jsx("span",{children:"Include complete sentences for more accurate tone detection"})]}),e.jsxs("div",{className:"flex items-start space-x-2",children:[e.jsx("div",{className:"w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"}),e.jsx("span",{children:"Longer emails provide more context for analysis"})]}),e.jsxs("div",{className:"flex items-start space-x-2",children:[e.jsx("div",{className:"w-2 h-2 bg-pink-500 rounded-full mt-2 flex-shrink-0"}),e.jsx("span",{children:"Remove personal information before analyzing"})]}),e.jsxs("div",{className:"flex items-start space-x-2",children:[e.jsx("div",{className:"w-2 h-2 bg-cyan-500 rounded-full mt-2 flex-shrink-0"}),e.jsx("span",{children:"Try different email types to see how tone varies"})]})]})]})]}),e.jsx("div",{className:"mt-8 p-6 bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl border border-yellow-200/50",children:e.jsxs("div",{className:"flex items-start space-x-3",children:[e.jsx("div",{className:"w-8 h-8 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1",children:e.jsx("svg",{className:"h-4 w-4 text-white",fill:"currentColor",viewBox:"0 0 20 20",children:e.jsx("path",{fillRule:"evenodd",d:"M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z",clipRule:"evenodd"})})}),e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold text-yellow-900 mb-2 flex items-center",children:"Important Disclaimer"}),e.jsxs("p",{className:"text-yellow-800 text-sm leading-relaxed mb-3",children:[e.jsx("strong",{children:"Please note:"})," This application currently uses simulated analysis algorithms for demonstration purposes. The results may not be entirely accurate as we are not yet implementing advanced Natural Language Processing (NLP) models."]}),e.jsxs("p",{className:"text-yellow-800 text-sm leading-relaxed",children:[e.jsx("strong",{children:"Future Development:"})," We are actively working on integrating state-of-the-art NLP technologies (such as BERT, GPT, and sentiment analysis libraries) to provide more accurate and reliable email tone analysis. Stay tuned for updates!"]})]})]})})]})]})};export{J as default};
